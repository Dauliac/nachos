#include "syscall.h"
int
main ()
{
    PutInt (1);
    //PutString("Voilà une deuxième phrase\n");
    //PutString("Une dernière et je quitte le programme\n");
    /* Halt(); */
    return 0;
}
